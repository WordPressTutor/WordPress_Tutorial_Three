jQuery(document).ready(function($) {
    $.getJSON('http://ip-api.com/json/?callback=?', function(data) {
        var country_code = data.countryCode.toLowerCase();
        var flag_class = 'flag-icon-' + country_code;

        // Append the flag icon to the specified container
        $('.aurthor-country-flag').html('<i class="flag-icon ' + flag_class + '"></i>');
    });
});