<?php
/*
Plugin Name: Custom Reviews 
Description: This is a custom reviews plugin that shows reviews.
Version: 1.0
Author: Patchmarket
*/

function custom_reviews_shortcode(){
    ob_start();
    include(plugin_dir_path(__FILE__) . 'templates/template-reviews.php');
    wp_enqueue_style('blog_archive_style', plugin_dir_url(__FILE__) . 'assets/css/style-reviews.css');
    wp_enqueue_script('blog_archive_script', plugin_dir_url(__FILE__) . 'assets/javascript/jquery-reviews.js');
    //wp_localize_script('blog_archive_script', 'ajaxurl', admin_url('admin-ajax.php'));
    $output = ob_get_clean();
    return $output;
}
add_shortcode('custom_reviews_shortcode', 'custom_reviews_shortcode');

// Add a new tab to WooCommerce product pages
function custom_reviews_tab($tabs) {
    $tabs['custom_reviews_tab'] = array(
        'title'     => __('Reviews', 'text-domain'),
        'priority'  => 50,
        'callback'  => 'display_custom_reviews_tab_content'
    );
    return $tabs;
}
add_filter('woocommerce_product_tabs', 'custom_reviews_tab');

// Display the content of your custom shortcode in the new tab
function display_custom_reviews_tab_content() {
    echo do_shortcode('[custom_reviews_shortcode]');
}






?>